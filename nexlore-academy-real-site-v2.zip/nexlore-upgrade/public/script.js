(function(){
  const box=document.createElement('div');box.className='support-fab';box.innerHTML='<a href="contact.html" title="درخواست تماس">پشتیبانی<br><small>درخواست تماس</small></a>';document.body.appendChild(box);
})();
