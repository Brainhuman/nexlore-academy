Nexlore Academy — Complete Static Website
Pages:
index.html        Home
courses.html      Courses
course.html       Dynamic course detail (use ?lang=english/german/french/korean)
about.html        About
contact.html      Contact
register.html     Registration / placement request
login.html        Login demo
dashboard.html    Learner dashboard demo

This is a front-end prototype. Forms are demo-only and do not send data to a server.
Replace demo numbers/text with verified business data before publishing.
Upload the entire folder to a static host such as Netlify, Vercel or GitHub Pages.
